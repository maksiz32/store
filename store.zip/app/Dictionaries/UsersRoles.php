<?php

namespace App\Dictionaries;

class UsersRoles
{
    public const USER_ROLES = [
        'Admin' => 20,
        'Client' => 10,
        'Customer' => 1,
    ];
}
